export interface Car {

        id: number;
        marka: String;
        model: String;
        rokProdukcji: String;
        paliwo: String;
        przebieg: String;
        moc: String;
        cena: String;
    }
