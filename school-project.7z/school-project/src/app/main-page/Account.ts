export interface Account {
    id: number;
    username: String;
    password: String;
}
