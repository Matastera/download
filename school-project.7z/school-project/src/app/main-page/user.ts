export interface ApplicationUser {
    username: String;
    password: String;
}
